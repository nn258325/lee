// 80mm 热敏小票排版（ESC/POS 指令）
// 输出 = Buffer 列表，print_daemon.ps1 把它们原样发到打印机
//   中文用 GBK(936)，西文用 CP437/CP850
'use strict';

// 菜单实际用到的汉字 GBK 编码表（零依赖内置）
//   生成方式：菜单 + config.json 所有汉字 → Windows API WideCharToMultiByte(936)
//   菜单新增汉字后请运行 extract_gbk.py 重新生成本表
// 菜单+页眉/页脚/小票文案 用到的汉字 GBK 编码表（共 305 字）
// 菜单+页眉/页脚/小票文案 用到的汉字 GBK 编码表（共 371 字）
// 菜单+页眉/页脚/小票文案 用到的汉字 GBK 编码表（共 375 字）
// 菜单+页眉/页脚/小票文案 用到的汉字 GBK 编码表（共 378 字）
// 菜单实际用到的汉字 GBK 编码表 → 外置到 gbk_table.json（菜单后台加菜后自动补字，无需改代码）
//   生成方式：菜单 + config.json + 小票文案 所有汉字 → Windows GBK(936) 编码
const fs = require('fs');
const path = require('path');
const GBK_TABLE = (() => {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'gbk_table.json'), 'utf8')); }
  catch (e) { return {}; }
})();
function reloadGbk() {
  try {
    const t = JSON.parse(fs.readFileSync(path.join(__dirname, 'gbk_table.json'), 'utf8'));
    for (const k in GBK_TABLE) delete GBK_TABLE[k];
    Object.assign(GBK_TABLE, t);
    return Object.keys(t).length;
  } catch (e) { return -1; }
}

// 把字符串按指定编码转 Buffer：
//   utf8 - 标准 UTF-8
//   gbk  - 中文用 GBK_TABLE 表内已收录汉字，西文/数字/ASCII 直接当 0x00-0x7F
//           （打印机已切到中文模式 FS & 时，ASCII 字符仍按单字节处理）
function encode(s, enc) {
  if (enc !== 'gbk') return Buffer.from(String(s), 'utf8');
  const out = [];
  for (const ch of String(s)) {
    const cp = ch.codePointAt(0);
    if (cp < 0x80) {
      // ASCII：原样发
      out.push(cp);
    } else if (GBK_TABLE[ch]) {
      // 已知中文：发 GBK 双字节
      out.push(GBK_TABLE[ch][0], GBK_TABLE[ch][1]);
    } else {
      // 未知汉字（含菜单临时新增）：退化为 '?'，避免打印出乱码字符
      //   这样老板能马上看到「漏字」而不是误导性的乱码
      out.push(0x3F); // '?'
    }
  }
  return Buffer.from(out);
}

// 字符显示宽度：中日韩字符占 2 列
function charW(ch) {
  const c = ch.codePointAt(0);
  if (c >= 0x1100 && c <= 0x115f) return 2;
  if (c >= 0x2e80 && c <= 0xa4cf) return 2;
  if (c >= 0xac00 && c <= 0xd7a3) return 2;
  if (c >= 0xf900 && c <= 0xfaff) return 2;
  if (c >= 0xfe30 && c <= 0xfe6f) return 2;
  if (c >= 0xff00 && c <= 0xff60) return 2;
  if (c >= 0xffe0 && c <= 0xffe6) return 2;
  return 1;
}
// 宽度计算统一按「1x1 西文列」为单位：
//   cnScale = 中文放大倍数（1~4），一个汉字占 2*cnScale 列
//   wScale  = 西文放大倍数（1~4），一个 ASCII 字符占 wScale 列
function cw(ch, cnScale, wScale) {
  const c = charW(ch);
  return c === 2 ? (2 * (cnScale || 1)) : (c * (wScale || 1));
}
function strW(s, cnScale, wScale) {
  let w = 0;
  for (const ch of String(s)) w += cw(ch, cnScale, wScale);
  return w;
}
function wrap(s, cols, cnScale, wScale) {
  const out = [];
  let line = '', w = 0;
  for (const ch of String(s)) {
    const c = cw(ch, cnScale, wScale);
    if (w + c > cols) { out.push(line); line = ch; w = c; }
    else { line += ch; w += c; }
  }
  if (line) out.push(line);
  return out.length ? out : [''];
}
function pad(s, cols, cnScale, wScale) {
  const padLen = Math.max(0, cols - strW(s, cnScale, wScale));
  return s + ' '.repeat(padLen);
}
function row(name, price, cols, cnScale, wScale) {
  const pw = strW(price, cnScale, wScale || 1);
  const nw = Math.max(8, cols - pw - 1);
  const lines = wrap(name, nw, cnScale, wScale);
  const out = [];
  lines.forEach((ln, i) => {
    out.push(i === lines.length - 1 ? pad(ln, cols - pw, cnScale, wScale) + price : ln);
  });
  return out;
}

// 防孤字：折行后如果最后一行只剩一个汉字（2 倍中文 = 4 列，阈值取 < 6），
// 从前一行末尾挪一个字下来，避免「虾」「扒」单独挂一行
function balance(lines, cols, cnScale, wScale) {
  for (let guard = 0; guard < 4 && lines.length > 1; guard++) {
    const last = lines[lines.length - 1];
    const prev = lines[lines.length - 2];
    if (strW(last, cnScale, wScale) >= 6) break;
    const pc = Array.from(prev);
    if (!pc.length) break;
    const ch = pc[pc.length - 1];
    if (ch === ' ') break;
    if (strW(ch + last, cnScale, wScale) > cols) break;
    pc.pop();
    lines[lines.length - 2] = pc.join('').replace(/\s+$/, '');
    lines[lines.length - 1] = ch + last;
  }
  return lines;
}

const ESC = 0x1b, GS = 0x1d, FS = 0x1c;

const CMD = {
  init:      [ESC, 0x40],              // ESC @  初始化
  left:      [ESC, 0x61, 0x00],
  center:    [ESC, 0x61, 0x01],
  right:     [ESC, 0x61, 0x02],
  boldOn:    [ESC, 0x45, 0x01],
  boldOff:   [ESC, 0x45, 0x00],
  // 西文字号（GS ! n：n 高 4 位 = 横向倍数、低 4 位 = 纵向倍数）
  size1:     [GS, 0x21, 0x00],         // 1x1（正常）
  sizeW2:    [GS, 0x21, 0x10],         // 2x1（只加宽）→ 数字/小标题用
  sizeH2:    [GS, 0x21, 0x01],         // 1x2（只加高）→ 数量行
  size2:     [GS, 0x21, 0x11],         // 2x2（宽高各 2 倍）→ 大标题/TOTAL
  // 中文字号（FS ! n：国产 80mm 固件扩展，n 高 4 位 = 宽、低 4 位 = 高）
  //   大部分国产机支持 0x00（1x1）/ 0x11（2x2）/ 0x22（3x3）/ 0x33（4x4）
  cnSize1:   [FS, 0x21, 0x00],
  cnSize2:   [FS, 0x21, 0x11],
  // 动态中文字号：cnSize(2)=2x2、cnSize(3)=3x3、cnSize(4)=4x4
  cnSize:    n => { const k = Math.max(1, Math.min(4, n | 0)); return [FS, 0x21, (k - 1) * 0x11]; },
  // 动态西文字号：只加高不加宽（宽度 1、高度 n）——和同倍数中文等高，混排不变形
  wsSize:    n => { const k = Math.max(1, Math.min(8, n | 0)); return [GS, 0x21, k - 1]; },
  cnOn:      [FS, 0x26],               // FS &  进入中文模式（GBK）
  cnOff:     [FS, 0x2e],               // FS .  退出中文模式
  cut:       [GS, 0x56, 0x42, 0x00],   // GS V B 0 切纸
  drawer:    [ESC, 0x70, 0x00, 0x19, 0xfa],
  feed:      n => [ESC, 0x64, n],
  lineSpace: n => [ESC, 0x33, n],      // ESC 3 n  设置行间距为 n 点（n=0..255，默认 30）
};

// 把一条指令直接编码成 Buffer
function cmd(x, enc) {
  if (typeof x === 'string') return encode(x, enc || 'utf8');
  if (Buffer.isBuffer(x)) return x;
  if (Array.isArray(x)) return Buffer.from(x);
  return Buffer.alloc(0);
}

// 文本块：可选编码 + 末尾换行
function txt(s, enc, nl) {
  return encode(String(s) + (nl ? '\n' : ''), enc || 'utf8');
}

const money = (n, sym) => (sym === '₡' ? '₡' : 'CRC') + ' ' + Number(n).toLocaleString('en-US');

function hhmmss(d) {
  const p = n => String(n).padStart(2, '0');
  return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}
function ddmmyyyy(d) {
  const p = n => String(n).padStart(2, '0');
  return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear();
}

// 中文行：自动套 FS & / FS .（已切中文模式的机器在切换瞬间可能漏字符，所以只包裹需要的行）
//   cnMode=false 时直接当 GBK 字节发，由打印机的默认编码处理（多数国产机默认 GBK）
function cnBuf(s, nl) {
  const b = encode(String(s) + (nl ? '\n' : ''), 'gbk');
  // 头尾包 FS & / FS .（开启中文模式）。即使 cnMode=false 也加，对国产机无副作用
  return Buffer.concat([Buffer.from([FS, 0x26]), b, Buffer.from([FS, 0x2e])]);
}

/**
 * 生成一张小票的指令列表
 * order = { id, table, type:'AQUI'|'LLEVAR', items:[{name, qty, price}], note, total, copy:'COCINA'|'CAJA' }
 * cfg   = { cols, header, footer, cut, drawer, lang:'both'|'es', cnMode, currency }
 */
function buildReceipt(order, cfg) {
  // cnScale     = 正文中文字号倍数（菜名/备注/页脚），默认 2（2x2）
  // cnScaleBig  = 重点行中文字号倍数（店名/TOTAL），默认 3（3x3）
  const c = Object.assign({ cols: 48, header: [], footer: [], cut: true, drawer: false, lang: 'both', currency: 'CRC', cnMode: true, cnScale: 2, cnScaleBig: 3 }, cfg || {});
  const CN = Math.max(1, Math.min(4, c.cnScale | 0));        // 正文中文字号
  const CNB = Math.max(CN, Math.min(4, c.cnScaleBig | 0));   // 重点行中文字号
  // 注意：西文一律保持原来的正常小字（size1），只有中文放大。
  //   曾经给西文加过「只加高不加宽」想跟中文等高，结果字母被拉长变形 —— 老板不要。
  //   老板口径：西班牙文不动，只改中文。
  const cols = c.cols;
  const line = '-'.repeat(cols);
  const dash = '='.repeat(cols);
  const out = [];
  const push = (...xs) => xs.forEach(x => out.push(x));

  push(cmd(CMD.init), cmd(CMD.left));
  // 行间距 48 点（约 6mm，原默认 30 太挤）；调大让中文行更透气
  push(cmd(CMD.lineSpace(48)));

  // 页眉（店名等）——首行加粗 + 2x2，店名一般是西文
  if (c.header && c.header.length) {
    push(cmd(CMD.center));
    c.header.forEach((h, i) => {
      if (!h) return;
      // 整行加粗 + 大字号
      push(cmd(CMD.boldOn));
      if (i === 0) {
        push(cmd(CMD.size2), cmd(CMD.cnSize(CNB)));   // 西文 2x2 + 中文大号
        wrap(h, cols, CNB, 2).forEach(ln => push(cnBuf(ln, true)));
        push(cmd(CMD.cnSize1), cmd(CMD.size1));
      } else {
        push(cmd(CMD.sizeW2), cmd(CMD.cnSize(CNB)));   // 西文保持原来的加宽样式（老板说西文不动）
        wrap(h, cols, CNB, 2).forEach(ln => push(cnBuf(ln, true)));
        push(cmd(CMD.cnSize1), cmd(CMD.size1));
      }
      push(cmd(CMD.boldOff));
    });
    push(cmd(CMD.size1), cmd(CMD.cnSize1));
  }

  // 桌号/用餐方式 + 订单号 + 时间 —— 加粗
  //   以前没填桌号时打「MOSTRADOR」（西语"柜台"），老板看不懂 → 改成双语
  push(cmd(CMD.left));
  push(cmd(line + '\n', 'cp437'));
  const d = new Date();
  push(cmd(CMD.size2), cmd(CMD.cnSize(2)), cmd(CMD.boldOn));
  if (order.table) {
    push(cmd('MESA ' + order.table + '\n', 'cp437'));
  } else if (order.type === 'LLEVAR') {
    push(cmd('LLEVAR / ', 'cp437'));
    push(cnBuf('外卖', true));
  } else {
    push(cmd('AQUI / ', 'cp437'));
    push(cnBuf('堂食', true));
  }
  push(cmd(CMD.size1), cmd(CMD.cnSize1));
  push(cmd('Orden #' + order.id + '   ' + ddmmyyyy(d) + ' ' + hhmmss(d) + '\n', 'cp437'));
  if (order.copy) push(cmd('*** ' + order.copy + ' ***\n', 'cp437'));
  push(cmd(CMD.boldOff));
  push(cmd(line + '\n', 'cp437'));

  // 菜品
  // 排版规则（v1.9）：
  //   1. 整行统一高度：西文 GS ! 只加高（宽 1 高 CN），中文 FS ! CN 倍 —— 一行里不再有大有小
  //   2. 菜名折行防孤字（不再出现「虾」「扒」单字挂行）
  //   3. 价格：名字最后一行放得下（留 2 列余量）就同一行；放不下就独立一行右对齐，不再硬挤
  order.items.forEach(it => {
    const name = (c.lang === 'es') ? String(it.name).split('/')[0].trim() : it.name;
    const qty = it.qty + 'x ';
    const total = money(it.qty * it.price, c.currency);
    const hs = CMD.size1;                          // 西文保持原样小字（不放大、不变形）
    const qtyW = strW(qty, CN, 1);
    const availW = cols - qtyW;                    // 名字区可用宽度（首行含数量前缀）
    const pw = strW(total, CN, 1);
    const nw = Math.max(8, availW - pw - 2);       // 名字折行宽度（给价格留出位置）
    const lines = balance(wrap(name, nw, CN, 1), nw, CN, 1);
    const lastW = strW(lines[lines.length - 1], CN, 1);
    const fit = lastW + pw + 2 <= availW;          // 2 列安全余量，防实际打印偏宽

    // 数量前缀：加粗（西文小字，跟以前一样），中文部分才放大
    push(cmd(CMD.boldOn), cmd(qty, 'cp437'), cmd(CMD.boldOff));
    push(cmd(CMD.cnSize(CN)));
    lines.forEach((ln, i) => {
      const isLast = i === lines.length - 1;
      if (isLast && fit) {
        push(cnBuf(pad(ln, availW - pw, CN, 1), false));   // 最后一行不带换行，价格接在后面
      } else {
        push(cnBuf(ln, !isLast || !fit));
      }
    });
    // 价格：西文区打印，与中文同高
    push(cmd(CMD.cnSize1), cmd(hs));
    if (fit) {
      push(cmd(' ' + total + '\n', 'cp437'));
      push(cmd(CMD.size1));
    } else {
      push(cmd(CMD.right), cmd(total + '\n', 'cp437'), cmd(CMD.left), cmd(CMD.size1));
    }
    push(cmd(CMD.cnSize1));
    if (it.note) {
      push(cmd(CMD.cnSize(CN)));
      balance(wrap('   -> ' + it.note, cols, CN, 1), cols, CN, 1).forEach(ln => push(cnBuf(ln, true)));
      push(cmd(CMD.cnSize1));
    }
  });

  push(cmd(CMD.center));
  push(cmd(dash + '\n', 'cp437'));
  // TOTAL 行 —— 2x2 加粗
  push(cmd(CMD.size2), cmd(CMD.boldOn), cmd(CMD.cnSize(CNB)));
  push(cmd('TOTAL ' + money(order.total, c.currency) + '\n', 'cp437'));
  push(cmd(CMD.cnSize1), cmd(CMD.size1), cmd(CMD.boldOff));
  push(cmd(CMD.left));

  if (order.note) {
    push(cmd(line + '\n', 'cp437'), cmd(CMD.boldOn), cmd(CMD.cnSize(CN)));
    push(cnBuf('Nota / 备注:', true));
    push(cmd(CMD.boldOff));
    balance(wrap(order.note, cols, CN, 1), cols, CN, 1).forEach(ln => push(cnBuf(ln, true)));
    push(cmd(CMD.cnSize1));
  }

  if (c.footer && c.footer.length) {
    push(cmd(CMD.center), cmd(line + '\n', 'cp437'), cmd(CMD.cnSize(CN)));
    c.footer.forEach(f => { if (f) balance(wrap(f, cols, CN, 1), cols, CN, 1).forEach(ln => push(cnBuf(ln, true))); });
    push(cmd(CMD.cnSize1));
  }

  // 票尾留白：cutFeed（点，203dpi）换算成文本行数；默认 12 点 ≈ 1 行，比原来的固定 3 行省纸
  const cf = (c.cutFeed === 0 || c.cutFeed) ? Number(c.cutFeed) : 12;
  const feedLines = Math.max(1, Math.round(cf / 24));
  push(cmd(CMD.feed(feedLines)));
  if (c.drawer) push(cmd(CMD.drawer));
  if (c.cut) push(cmd(CMD.cut));
  return out;
}

/**
 * 位图模式用的「票据描述」（不是指令流）
 *   print_daemon.ps1 拿到它后用 Windows 宋体渲染成位图，再按 ESC/POS 图形指令打印。
 *   好处：字体是真正的宋体、字号就是 12pt（小四），排版由 GDI 真实测量 → 不会错位/变形。
 * size 单位 = 磅(pt)：小四 = 12pt
 */
function buildTicketSpec(order, cfg) {
  const c = Object.assign({
    cols: 48, header: [], footer: [], cut: true, drawer: false, lang: 'both', currency: 'CRC',
    fontCN: 'SimSun', fontES: 'Arial', sizeCN: 12, sizeES: 9, sizeBig: 19, sizeSmall: 10,
    width: 576, pad: 10, dpi: 203, feed: 12, lineGap: 1.2, cutFeed: 12
  }, cfg || {});
  const S = Number(c.sizeCN) || 12;      // 中文：小四 12pt
  const ES = Number(c.sizeES) || 9;      // 西文：小字（和原来热敏小字差不多大）
  const BIG = Number(c.sizeBig) || 19;   // 店名 / TOTAL
  const d = new Date();
  const lines = [];

  (c.header || []).forEach((h, i) => {
    if (!h) return;
    lines.push({ t: String(h), size: i === 0 ? BIG : ES + 2, bold: true, align: 'center' });
  });
  lines.push({ rule: 'dashed' });

  // 桌号 / 用餐方式：以前打 MOSTRADOR（西语"柜台"）老板看不懂 → 双语
  const lugar = order.table ? ('MESA ' + order.table)
    : (order.type === 'LLEVAR' ? 'LLEVAR / 外卖' : 'AQUI / 堂食');
  lines.push({ t: lugar, size: S + 3, bold: true });
  lines.push({ t: 'Orden #' + order.id + '   ' + ddmmyyyy(d) + ' ' + hhmmss(d), size: ES });
  if (order.copy) lines.push({ t: '*** ' + order.copy + ' ***', size: ES + 1, bold: true, align: 'center' });
  lines.push({ rule: 'dashed' });

  order.items.forEach(it => {
    const name = (c.lang === 'es') ? String(it.name).split('/')[0].trim() : it.name;
    // 价格走西文字体（Arial），所以用 CRC 而不是 ₡ —— 避免 Arial 缺 ₡ 字形变成方框
    const total = money(it.qty * it.price, 'CRC');
    lines.push({ t: it.qty + 'x  ' + name, right: total, size: S, bold: true });
    if (it.note) lines.push({ t: '   -> ' + it.note, size: Math.max(8, S - 1) });
  });

  lines.push({ rule: 'double' });
  lines.push({ t: 'TOTAL', right: money(order.total, 'CRC'), size: BIG, bold: true });
  lines.push({ rule: 'dashed' });

  if (order.note) lines.push({ t: 'Nota / 备注: ' + order.note, size: S });
  (c.footer || []).forEach(f => { if (f) lines.push({ t: String(f), size: S, align: 'center' }); });

  return {
    width: Number(c.width) || 576,
    pad: Number(c.pad) || 10,
    dpi: Number(c.dpi) || 203,
    fontCN: c.fontCN, fontES: c.fontES,
    feed: (c.feed === 0 || c.feed) ? Number(c.feed) : 12,          // 切纸前走纸点数（8点≈1mm）
    lineGap: Number(c.lineGap) || 1.2,                             // 行距系数
    cut: !!c.cut, drawer: !!c.drawer,
    lines
  };
}

/**
 * 日结单（每日总结单）的「票据描述」，同样交给 print_daemon.ps1 位图渲染。
 * sum = summarizeDay() 的结果：
 *   { day:'YYYYMMDD', orders:N, total:N, types:{AQUI:{n,amt},LLEVAR:{n,amt},MESA:{n,amt}},
 *     items:[{name, qty, amt}]（已按 qty 降序） }
 */
function buildSummarySpec(sum, cfg) {
  const c = Object.assign({
    header: [], footer: [], fontCN: 'SimSun', fontES: 'Arial',
    sizeCN: 12, sizeES: 9, sizeBig: 19,
    width: 576, pad: 10, dpi: 203, feed: 12, lineGap: 1.2, cut: true, drawer: false
  }, cfg || {});
  const S = Number(c.sizeCN) || 12;
  const ES = Number(c.sizeES) || 9;
  const BIG = Number(c.sizeBig) || 19;
  const d = new Date();
  const lines = [];

  (c.header || []).forEach((h, i) => {
    if (!h) return;
    lines.push({ t: String(h), size: i === 0 ? BIG - 4 : ES + 2, bold: i === 0, align: 'center' });
  });
  lines.push({ t: 'RESUMEN DEL DIA / 当日总结', size: 15, bold: true, align: 'center' });

  // YYYYMMDD -> dd/mm/yyyy
  const day = String(sum.day || '');
  const dd = day.slice(6, 8), mm = day.slice(4, 6), yy = day.slice(0, 4);
  lines.push({ t: 'Fecha / 日期: ' + dd + '/' + mm + '/' + yy, size: ES + 1 });
  lines.push({ rule: 'dashed' });

  if (!sum.orders) {
    lines.push({ t: 'SIN VENTAS / 今日无单', size: S, bold: true, align: 'center' });
    lines.push({ t: 'Impreso ' + ddmmyyyy(d) + ' ' + hhmmss(d), size: ES });
    return {
      width: Number(c.width) || 576, pad: Number(c.pad) || 10, dpi: Number(c.dpi) || 203,
      fontCN: c.fontCN, fontES: c.fontES,
      feed: (c.feed === 0 || c.feed) ? Number(c.feed) : 12, lineGap: Number(c.lineGap) || 1.2,
      cut: !!c.cut, drawer: !!c.drawer, lines
    };
  }

  lines.push({ t: 'ORDENES 单数: ' + sum.orders, size: S });
  lines.push({ t: 'TOTAL VENDIDO 总营业额', size: S });
  lines.push({ t: money(sum.total, 'CRC'), size: BIG, bold: true, align: 'right' });
  lines.push({ rule: 'dashed' });

  // 堂食 / 外卖 / 桌号
  const ty = sum.types || {};
  const typeRows = [
    ['AQUI 堂食', ty.AQUI], ['LLEVAR 外卖', ty.LLEVAR], ['MESA 桌号', ty.MESA]
  ];
  typeRows.forEach(([label, v]) => {
    if (!v || !v.n) return;
    lines.push({ t: label + ': ' + v.n + ' 单', right: money(v.amt, 'CRC'), size: S - 1 });
  });
  lines.push({ rule: 'dashed' });

  // 三种支付方式：现金 / 刷卡 / SINPE（旧订单没记支付方式的算「未记录」）
  const py = sum.pays || {};
  const unk = sum.payUnknown || { n: 0, amt: 0 };
  const payRows = [
    ['EFECTIVO 现金', py.EFECTIVO],
    ['TARJETA 刷卡', py.TARJETA],
    ['SINPE 转账', py.SINPE]
  ];
  lines.push({ t: 'FORMA DE PAGO / 支付方式', size: S, bold: true });
  payRows.forEach(([label, v]) => {
    if (!v || !v.n) return;
    lines.push({ t: label + ': ' + v.n + ' 单', right: money(v.amt, 'CRC'), size: S - 1 });
  });
  if (unk.n) lines.push({ t: 'SIN REGISTRO 未记录: ' + unk.n + ' 单', right: money(unk.amt, 'CRC'), size: S - 1 });
  if (!py.EFECTIVO.n && !py.TARJETA.n && !py.SINPE.n) {
    lines.push({ t: '(旧订单未记支付方式，升级后新单开始记录)', size: S - 1 });
  }
  lines.push({ rule: 'dashed' });

  // 菜品销量默认不打（老板要求日结单短一点）；要打的话 config 里 "summaryShowItems": true
  if (c.summaryShowItems) {
    lines.push({ t: 'VENTAS POR PLATO / 菜品销量', size: S, bold: true });
    (sum.items || []).forEach(it => {
      lines.push({ t: it.qty + 'x  ' + it.name, right: money(it.amt, 'CRC'), size: S - 1 });
    });
    lines.push({ rule: 'dashed' });
  }

  (c.footer || []).forEach(f => { if (f) lines.push({ t: String(f), size: S, align: 'center' }); });
  lines.push({ t: 'Impreso ' + ddmmyyyy(d) + ' ' + hhmmss(d), size: ES });

  return {
    width: Number(c.width) || 576, pad: Number(c.pad) || 10, dpi: Number(c.dpi) || 203,
    fontCN: c.fontCN, fontES: c.fontES,
    feed: (c.feed === 0 || c.feed) ? Number(c.feed) : 12, lineGap: Number(c.lineGap) || 1.2,
    cut: !!c.cut, drawer: !!c.drawer, lines
  };
}

module.exports = { buildReceipt, buildTicketSpec, buildSummarySpec, wrap, balance, strW, pad, row, money, CMD, GBK_TABLE, encode, reloadGbk };