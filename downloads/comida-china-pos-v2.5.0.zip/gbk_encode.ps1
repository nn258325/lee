# gbk_encode.ps1 - encode CJK chars to GBK(936) byte pairs, output JSON map
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File gbk_encode.ps1 -InFile chars.txt -OutFile map.json
# NOTE: keep this file pure ASCII (no BOM needed); Chinese comments broke parsing under GBK codepage.
param(
  [Parameter(Mandatory=$true)][string]$InFile,
  [Parameter(Mandatory=$true)][string]$OutFile
)
$ErrorActionPreference = 'Stop'
try {
  $chars = [System.IO.File]::ReadAllText($InFile, [System.Text.Encoding]::UTF8)
  $enc = [System.Text.Encoding]::GetEncoding(936)
  $map = @{}
  foreach ($ch in $chars.ToCharArray()) {
    $code = [int]$ch
    # CJK blocks only: ideographs / CJK punct / fullwidth forms (ASCII goes CP437, not GBK)
    $isCJK = ($code -ge 0x2E80 -and $code -le 0x9FFF) -or ($code -ge 0xF900 -and $code -le 0xFAFF) -or ($code -ge 0xFF00 -and $code -le 0xFFEF)
    if (-not $isCJK) { continue }
    if ($map.ContainsKey($ch)) { continue }
    $b = $enc.GetBytes([string]$ch)
    if ($b.Length -eq 2) { $map[$ch] = @([int]$b[0], [int]$b[1]) }
  }
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append('{')
  $first = $true
  foreach ($k in $map.Keys) {
    if (-not $first) { [void]$sb.Append(',') }
    $first = $false
    $hex = '{0},{1}' -f $map[$k][0], $map[$k][1]
    [void]$sb.Append('"' + $k + '":[' + $hex + ']')
  }
  [void]$sb.Append('}')
  [System.IO.File]::WriteAllText($OutFile, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
  Write-Output ("OK " + $map.Count)
} catch {
  Write-Output ("ERR " + $_.Exception.Message)
  exit 1
}
