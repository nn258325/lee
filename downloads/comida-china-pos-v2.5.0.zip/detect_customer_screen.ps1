# detect_customer_screen.ps1 - list displays, output non-primary bounds
# Output: "OK X Y W H" for the non-primary screen, or diagnostics (COUNT/SCR/ERR lines)
$ErrorActionPreference = 'SilentlyContinue'
$loaded = $false
try { Add-Type -AssemblyName System.Windows.Forms; $loaded = $true } catch {
  try {
    [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
    $loaded = $true
  } catch {
    Write-Output ("ERR Add-Type failed: " + $_.Exception.Message)
  }
}
if ($loaded) {
  $s = $null
  try {
    $s = [System.Windows.Forms.Screen]::AllScreens | Where-Object { $_.Primary -eq $false } | Select-Object -First 1
  } catch {
    Write-Output ("ERR AllScreens failed: " + $_.Exception.Message)
  }
  if ($s) {
    Write-Output ("OK " + $s.Bounds.X + " " + $s.Bounds.Y + " " + $s.Bounds.Width + " " + $s.Bounds.Height)
  } else {
    try {
      $all = @([System.Windows.Forms.Screen]::AllScreens)
      Write-Output ("COUNT " + $all.Count)
      foreach ($x in $all) {
        Write-Output ("SCR " + $x.DeviceName + " primary=" + $x.Primary + " pos=" + $x.Bounds.X + "," + $x.Bounds.Y + " size=" + $x.Bounds.Width + "x" + $x.Bounds.Height)
      }
      Write-Output "NONE"
    } catch {
      Write-Output ("ERR list failed: " + $_.Exception.Message)
    }
  }
}
