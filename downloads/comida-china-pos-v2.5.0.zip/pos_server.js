// 前台点单本地服务：供页面 + 收单 + 打小票 + 存单
// 只用 Node 自带模块，不需要 npm install
'use strict';
const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, execFile } = require('child_process');
const { buildReceipt, buildTicketSpec, buildSummarySpec, GBK_TABLE, reloadGbk } = require('./escpos');

const ROOT = __dirname;
const SERVER_V = '2.5.0';   // 每次发版改这里，页面对不上就提示重启服务
const PORT = Number(process.env.POS_PORT || 8899);
const ORDERS_DIR = path.join(ROOT, 'orders');
// 配置存到系统用户目录（%APPDATA%\ComidaChinaPOS\config.json）：
//   这样以后解压新版本覆盖程序文件夹时，已保存的打印机设置不会被 zip 里的默认配置覆盖
//   程序目录里的 config.json 只作为「首次运行的默认模板」，不再被读写
const CFG_DIR = path.join(os.homedir(), 'AppData', 'Roaming', 'ComidaChinaPOS');
const CFG_PATH = path.join(CFG_DIR, 'config.json');
const CFG_TEMPLATE = path.join(ROOT, 'config.json');
// 打印用的 C# 小工具编译一次后缓存成 DLL，放在配置同目录：
//   以后每次启动守护进程直接加载 DLL（约 0.1 秒），不再现编译（要 2~6 秒）
const DLL_PATH = path.join(CFG_DIR, 'RawPrinterHelper.dll');
const OPEN_BROWSER = process.argv.includes('--open');   // 双击启动时自动开浏览器

// 初始化用户配置：不存在则从程序目录模板复制；模板也没有则用内置默认值
function initCfg() {
  if (fs.existsSync(CFG_PATH)) return;
  fs.mkdirSync(CFG_DIR, { recursive: true });
  try {
    if (fs.existsSync(CFG_TEMPLATE)) {
      fs.copyFileSync(CFG_TEMPLATE, CFG_PATH);
      console.log('已把程序目录的 config.json 复制为用户配置: ' + CFG_PATH);
      return;
    }
  } catch (e) { /* 复制失败则走内置默认 */ }
  const DEFAULT_CFG = {
    printer: '', mode: 'raw', paper: 80, cols: 48,
    copies: ['COCINA'], cut: true, drawer: false,
    lang: 'both', currency: 'CRC', cnMode: true,
    serviceFeePct: 10,   // 堂食服务费比例（0=不收）
    header: ['COMIDA CHINA', 'Tel 6098-8889'],
    footer: ['Gracias / 谢谢惠顾']
  };
  fs.writeFileSync(CFG_PATH, JSON.stringify(DEFAULT_CFG, null, 2), 'utf8');
  console.log('已生成默认用户配置: ' + CFG_PATH);
}
initCfg();

// 不依赖系统默认浏览器关联，自己挑一个能跑的浏览器打开
function openBrowser() {
  const url = 'http://127.0.0.1:' + PORT + '/';
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files\\Internet Explorer\\iexplore.exe',
    'C:\\Program Files (x86)\\Internet Explorer\\iexplore.exe'
  ];
  for (const exe of candidates) {
    if (fs.existsSync(exe)) {
      try {
        const p = spawn(exe, [url], { detached: true, stdio: 'ignore' });
        p.on('error', () => {});
        p.unref();
        console.log('已用浏览器打开: ' + exe);
        return true;
      } catch (e) {}
    }
  }
  console.log('=========================================');
  console.log(' 没找到任何可用的浏览器，请手动打开：');
  console.log('   http://127.0.0.1:' + PORT + '/');
  console.log(' （电脑要装 Edge / Chrome / IE 任意一个）');
  console.log('=========================================');
  return false;
}

// ---------- 客屏自动打开 ----------
// 和 openBrowser 同一机制（Node 直接 spawn 浏览器），不经过 bat / PowerShell 链条。
// 副屏定位优先级：config.custPos（手工指定 "X,Y" 或 "X,Y,W,H"）> 上次检测缓存 > PowerShell 现场检测。
// 检测给 12 秒超时并重试一次（收银机 PowerShell 冷启动慢，4 秒会误杀）。成功后缓存，下次秒开。
// 每次服务启动：旧客屏窗口还开着就先关掉，再按目标位置重新开，保证位置永远跟最新结果走。
const CUST_MARK = path.join(CFG_DIR, 'custscreen.json');

function pidAlive(pid) {
  try {
    const out = require('child_process').execSync(
      'tasklist /FI "PID eq ' + pid + '" /FO CSV /NH', { timeout: 4000, windowsHide: true }).toString();
    return out.toLowerCase().includes('msedge') || out.toLowerCase().includes('chrome');
  } catch (e) { return false; }
}

function killOldCustomer(pid) {
  try {
    require('child_process').execSync('taskkill /PID ' + pid + ' /T /F',
      { timeout: 5000, windowsHide: true, stdio: 'ignore' });
    console.log('[客屏] 已关闭旧客屏窗口（PID ' + pid + '），重新按目标位置开');
  } catch (e) { /* 已死了就算了 */ }
}

function detectSecondScreen(cb) {
  // 返回 "X,Y,W,H"（副屏边界）或 null。
  // 用打印守护进程同款调用方式（powershell -File 脚本.ps1，-Command 内联方式在部分收银机上被拦）。
  // 检测失败时把诊断行打进黑窗口（Windows 看到几块屏、哪块是主屏），方便远程定位。
  const psFile = path.join(ROOT, 'detect_customer_screen.ps1');
  const once = next => {
    let done = false;
    const finish = v => { if (!done) { done = true; next(v); } };
    try {
      const c = spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', psFile],
        { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      let buf = '';
      c.stdout.on('data', d => { buf += d; });
      c.stderr.on('data', d => { buf += d; });
      c.on('error', e => { console.log('[客屏] 检测进程启动失败: ' + e.message); finish(null); });
      c.on('close', code => {
        const m = /^OK\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s*$/m.exec(buf);
        if (m) { finish([m[1], m[2], m[3], m[4]].join(',')); return; }
        console.log('[客屏] 检测没成功（退出码 ' + code + '），诊断信息：');
        buf.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 8)
          .forEach(l => console.log('  [客屏诊断] ' + l));
        finish(null);
      });
      setTimeout(() => { try { c.kill(); } catch (e) {} finish(null); }, 20000);
    } catch (e) { finish(null); }
  };
  once(v => {
    if (v) cb(v);
    else { console.log('[客屏] 第一次检测没成功，再试一次…'); once(cb); }
  });
}

function launchCustomer(exe, url, pos, src) {
  const args = ['--new-window', '--no-first-run', '--no-default-browser-check',
    '--user-data-dir=' + path.join(os.tmpdir(), 'comidachina-custscreen')];
  if (pos) {
    const p = pos.split(',');
    args.push('--window-position=' + p[0] + ',' + p[1]);
    if (p.length >= 4) args.push('--window-size=' + p[2] + ',' + p[3]);
    args.push('--kiosk');   // kiosk 全屏跟随窗口位置，定位比 --start-fullscreen 可靠
    console.log('[客屏] 目标位置 ' + pos + ' ' + src + '，kiosk 全屏打开');
  } else {
    args.push('--start-fullscreen');
    console.log('[客屏] 没有坐标，先开在本屏全屏（Alt+F4 可关）');
  }
  try {
    const pr = spawn(exe, args.concat([url]), { detached: true, stdio: 'ignore' });
    pr.on('error', e => console.log('[客屏] 启动浏览器失败: ' + e.message));
    pr.unref();
    try { fs.writeFileSync(CUST_MARK, JSON.stringify({ pid: pr.pid, ts: Date.now(), pos: pos || '' }), 'utf8'); } catch (e) {}
    console.log('[客屏] 已打开: ' + exe);
  } catch (e) {
    console.log('[客屏] 启动失败: ' + e.message + '（可双击 启动客屏.bat 手动开）');
  }
}

function openCustomerScreen() {
  const url = 'http://127.0.0.1:' + PORT + '/customer.html';
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
  ];
  let exe = null;
  for (const c of candidates) if (fs.existsSync(c)) { exe = c; break; }
  if (!exe) {
    console.log('[客屏] 没找到 Edge / Chrome，客屏未打开（可装一个浏览器后重启服务）');
    return;
  }
  // 旧窗口还开着就先关（保证位置跟最新检测/配置走，也不会越积越多）
  let mark = null;
  try {
    mark = fs.existsSync(CUST_MARK) ? JSON.parse(fs.readFileSync(CUST_MARK, 'utf8')) : null;
    if (mark && mark.pid && Date.now() - mark.ts < 12 * 3600 * 1000 && pidAlive(mark.pid)) killOldCustomer(mark.pid);
  } catch (e) {}
  // 目标位置：手工指定 > 缓存 > 现场检测
  let override = null;
  try { override = readCfg().custPos || null; } catch (e) {}
  if (override) {
    launchCustomer(exe, url, override, '(config.custPos 手工指定)');
    return;
  }
  if (mark && mark.pos) {
    launchCustomer(exe, url, mark.pos, '(上次检测缓存)');
    return;
  }
  console.log('[客屏] 正在检测第二块屏（第一次可能要十几秒，请稍等）…');
  detectSecondScreen(pos => {
    if (pos) launchCustomer(exe, url, pos, '(现场检测，已缓存下次秒开)');
    else {
      console.log('[客屏] 检测不到第二块屏。客屏先开在本屏；');
      console.log('        把客屏在屏1的左边还是右边告诉 AI，写进 config 的 custPos 就永远开对。');
      launchCustomer(exe, url, null, '');
    }
  });
}

fs.mkdirSync(ORDERS_DIR, { recursive: true });
const readCfg = () => JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));
const writeCfg = c => fs.writeFileSync(CFG_PATH, JSON.stringify(c, null, 2), 'utf8');

// ---------- 菜单 ----------
function loadMenu() {
  const raw = JSON.parse(fs.readFileSync(path.join(ROOT, 'menu.json'), 'utf8'));
  const cats = Object.keys(raw).map(k => raw[k]);
  cats.forEach(c => { c.name = c.name.slice(c.name.indexOf('>') + 1).trim(); });
  return cats;
}

// ---------- 菜单后台：保存菜单 + GBK 字库自动补字 ----------
const CJK_RE = /[\u2E80-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF]/g;

function gbkMissing(text) {
  const set = new Set();
  const m = text.match(CJK_RE) || [];
  for (const ch of m) if (!GBK_TABLE[ch]) set.add(ch);
  return [...set];
}

function runGbkEncoder(chars) {
  // 调 gbk_encode.ps1（-File 方式，收银机验证可行）把缺字编成 GBK 字节
  const stamp = Date.now();
  const inFile = 'C:/Windows/Temp/gbk_chars_' + stamp + '.txt';
  const outFile = 'C:/Windows/Temp/gbk_map_' + stamp + '.json';
  fs.writeFileSync(inFile, [...new Set(chars)].join(''), 'utf8');
  const psFile = path.join(ROOT, 'gbk_encode.ps1');
  try {
    const out = require('child_process').execSync(
      'powershell -NoProfile -ExecutionPolicy Bypass -File "' + psFile + '" -InFile "' + inFile + '" -OutFile "' + outFile + '"',
      { timeout: 30000, windowsHide: true, encoding: 'utf8' });
    const map = fs.existsSync(outFile) ? JSON.parse(fs.readFileSync(outFile, 'utf8')) : {};
    return { map, count: Object.keys(map).length, err: Object.keys(map).length ? null : String(out).trim() };
  } catch (e) {
    return { map: {}, count: 0, err: e.message };
  } finally {
    try { fs.unlinkSync(inFile); } catch (e) {}
    try { fs.unlinkSync(outFile); } catch (e) {}
  }
}

function gbkRebuild(scanEscpos) {
  // 扫描菜单+配置(+escpos 小票文案)所有 CJK 字，缺的补进 gbk_table.json 并热加载（不用重启服务）
  let text = fs.readFileSync(path.join(ROOT, 'menu.json'), 'utf8') +
             fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8');
  if (scanEscpos) text += fs.readFileSync(__dirname + '/escpos.js', 'utf8');
  const missing = gbkMissing(text);
  if (!missing.length) return { ok: true, added: 0, total: Object.keys(GBK_TABLE).length, missing: [] };
  const r = runGbkEncoder(missing);
  if (!r.count) return { ok: false, added: 0, total: Object.keys(GBK_TABLE).length, missing, err: r.err || '字库编码器无输出' };
  const tableFile = path.join(ROOT, 'gbk_table.json');
  const merged = Object.assign(JSON.parse(fs.readFileSync(tableFile, 'utf8')), r.map);
  fs.writeFileSync(tableFile, JSON.stringify(merged), 'utf8');
  return { ok: true, added: r.count, total: reloadGbk(), missing: [] };
}

// ---------- 单号 ----------
function nextId() {
  const d = new Date();
  const day = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  const file = path.join(ORDERS_DIR, day + '.jsonl');
  fs.mkdirSync(ORDERS_DIR, { recursive: true });
  let n = 1;
  if (fs.existsSync(file)) n = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).length + 1;
  return { id: String(n).padStart(4, '0'), day, file };
}

// ---------- 列出本机打印机 ----------
// 用一次性的子进程查询（启动开销影响不大，列表请求不频繁）
function runPowershell(args, timeout) {
  return new Promise(res => {
    const p = spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args], { windowsHide: true });
    let out = '';
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => out += d);
    const t = setTimeout(() => p.kill(), timeout || 20000);
    p.on('close', code => { clearTimeout(t); res({ code, out }); });
  });
}
async function listPrinters() {
  const r = await runPowershell(['-Command',
    '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; ' +
    'Get-Printer | ForEach-Object { $_.Name + "|" + $_.DriverName + "|" + $_.Default }'], 15000);
  return r.out.split('\n').map(s => s.trim()).filter(Boolean).map(s => {
    const [name, driver, def] = s.split('|');
    return { name, driver, default: /true/i.test(def || '') };
  });
}

// 快速列表 A：问常驻守护进程（进程是热的，不用再启 PowerShell；它内部缓存了注册表扫描结果）
//   实测对比：Get-Printer 一次 5.4 秒，这是下单慢的头号元凶
async function listPrintersFast(force) {
  const r = await daemonRequest(force ? 'LISTF' : 'LIST', 8000);
  const m = /^LIST\s+(\S+)/.exec(r.body || '');
  if (!m) return [];
  const json = JSON.parse(Buffer.from(m[1], 'base64').toString('utf8'));
  const def = json.default || '';
  return (json.names || []).map(n => ({ name: n, driver: '', default: n === def }));
}

// 快速列表 B（兜底）：守护进程没起来时，直接查注册表（比 Get-Printer 快约 8 倍）
async function listPrintersFallback() {
  const r = await runPowershell(['-Command',
    "$d=''; try { $d = (Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows' -Name Device).Device } catch {}; " +
    "Write-Output ('D|' + (($d -split ',')[0])); " +
    "Get-ChildItem 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Print\\Printers' | ForEach-Object { Write-Output ('P|' + $_.PSChildName) }"], 15000);
  let def = '';
  const names = [];
  r.out.split('\n').map(s => s.trim()).filter(Boolean).forEach(s => {
    if (s.startsWith('D|')) def = s.slice(2);
    else if (s.startsWith('P|')) names.push(s.slice(2));
  });
  return names.map(n => ({ name: n, driver: '', default: n === def }));
}

// 打印机列表缓存：只对「设置页 / 自动挑打印机」有意义
//   打印路径本身已不再枚举设备（配置里选了哪台就用哪台）
let printerCache = { ts: 0, list: [] };
const PRINTER_CACHE_MS = 300000;   // 5 分钟
let lastPrint = null;   // 最近一次打印结果（异步打印后前端回查）
async function listPrintersCached(force) {
  const now = Date.now();
  if (!force && printerCache.list.length && (now - printerCache.ts) < PRINTER_CACHE_MS) {
    return printerCache.list;
  }
  const t = Date.now();
  let list = null;
  try { list = await listPrintersFast(force); } catch (e) { list = null; }
  if (!list || !list.length) {
    try { list = await listPrintersFallback(); } catch (e) { list = []; }
  }
  if (!list.length) {
    // 最后的兜底：慢，但至少能出结果
    try { list = await listPrinters(); } catch (e) { list = []; }
  }
  console.log('[printers] 查询耗时=' + (Date.now() - t) + 'ms 结果=' + list.length + ' 台');
  printerCache = { ts: Date.now(), list };
  return list;
}

// 决定这次打印用哪台打印机：配置里的优先；没配置/名字不存在 → 自动挑一台（跳过 PDF 虚拟打印机）
async function resolvePrinter(cfg, printers) {
  const want = (cfg.printer || '').trim();
  if (want && printers.some(p => p.name === want)) return { name: want, warn: '' };
  const real = printers.filter(p => !/pdf/i.test(p.name));
  const def = (real.find(p => p.default) || real[0] || printers.find(p => p.default) || printers[0]);
  if (want && printers.length) return { name: def ? def.name : '', warn: '设置的打印机「' + want + '」在这台电脑上不存在' + (def ? '，已改用「' + def.name + '」' : '') };
  if (def) return { name: def.name, warn: '还没选打印机，自动使用「' + def.name + '」' };
  return { name: '', warn: '这台电脑没检测到任何打印机：请确认打印机已插好并装好驱动，再到「打印机设置」里选择' };
}

// 打印失败时才用：重新扫一遍设备，挑一台跟刚才不同的（只在出错路径上付费）
async function reResolvePrinter(failedName) {
  try {
    const list = await listPrintersCached(true);
    const rp = await resolvePrinter({ printer: '' }, list);
    if (rp.name && rp.name !== failedName) return rp.name;
  } catch (e) {}
  return '';
}

// 打印：常驻 PowerShell 守护进程，避免每次启动 300-500ms 开销
// 协议：stdin 发送一行 "PRINT|<打印机名>|<绝对路径>\n"，stdout 返回 "OK bytes=N\n" 或 "ERR <message>\n"
let psDaemon = null;        // PowerShell 子进程
let psReady = false;        // 是否就绪（收到 READY 标记后）
let psOutBuf = '';          // 行缓冲
let psReqSeq = 0;           // 请求序号，配合 pending Map
let psSock = null;          // 与守护进程的 TCP 连接
let psServer = null;        // 本机 TCP 服务（守护进程连回来）
const psPending = new Map();// seq -> {resolve, reject, timer}

// 收守护进程的一行（TCP 或 stdout 都能用）
function feedDaemon(text) {
  psOutBuf += text;
  let i;
  while ((i = psOutBuf.indexOf('\n')) >= 0) {
    const line = psOutBuf.slice(0, i).replace(/\r$/, '');
    psOutBuf = psOutBuf.slice(i + 1);
    handleDaemonLine(line);
  }
}

function startDaemon() {
  if (psDaemon && !psDaemon.killed) return;
  psReady = false; psOutBuf = ''; psSock = null;
  const psFile = path.join(ROOT, 'print_daemon.ps1');

  // 用本机 TCP 通信（管道 stdin/stdout 往返实测约 1000ms，TCP 可到 100ms 内）
  if (psServer) { try { psServer.close(); } catch (e) {} psServer = null; }
  psServer = net.createServer(sock => {
    psSock = sock;
    sock.setNoDelay(true);
    sock.on('data', d => feedDaemon(d.toString('utf8')));
    sock.on('error', e => console.log('[daemon-tcp] socket error: ' + e.message));
    sock.on('close', () => { console.log('[daemon-tcp] 连接关闭'); psSock = null; psReady = false; });
  });
  psServer.on('error', e => console.log('[daemon-tcp] server error: ' + e.message));
  psServer.listen(0, '127.0.0.1', () => {
    const port = psServer.address().port;
      psDaemon = spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', psFile,
        '-Port', String(port), '-Dll', DLL_PATH, '-Dir', ROOT], { windowsHide: true });
    psDaemon.stdout.on('data', d => { const s = d.toString('utf8').trim(); if (s) console.log('[ps-daemon]', s); });
    psDaemon.stderr.on('data', d => {
      const s = d.toString('utf8').trim();
      if (s) console.error('[ps-daemon]', s);
    });
    psDaemon.on('exit', code => {
      psReady = false;
      // 让所有在等的请求失败（不 hang 死）
      psPending.forEach(p => { clearTimeout(p.timer); p.reject(new Error('PowerShell 守护进程已退出 code=' + code)); });
      psPending.clear();
      // 自动重启（但避免疯狂重启）
      if (!psDaemon._exiting) {
        setTimeout(() => { try { startDaemon(); } catch (e) {} }, 1000);
      }
    });
  });
}

// 统一解析守护进程回包："#<seq> <正文>[ ms=<n>]"
//   正文可能是：OK bytes=N / ERR xxx / PONG / LIST <base64>
function handleDaemonLine(line) {
  if (line === 'READY' || line === 'EARLY') { psReady = true; return; }
  if (!line.startsWith('#')) return;
  const m = line.match(/^#(\d+)\s+(.*)$/);
  if (!m) return;
  const seq = Number(m[1]);
  const p = psPending.get(seq);
  if (!p) return;
  psPending.delete(seq);
  clearTimeout(p.timer);
  let rest = m[2] || '';
  let ms = null;
  const mm = rest.match(/\sms=(\d+)\s*$/);
  if (mm) { ms = Number(mm[1]); rest = rest.slice(0, mm.index); }
  p.resolve({ ok: true, ms, body: rest });
}

// 通用请求：verb = PING / LIST / LISTF / PRINT
async function daemonRequest(verb, timeoutMs, extra) {
  if (!psDaemon || psDaemon.killed) startDaemon();
  await ensureDaemonReady();
  const seq = ++psReqSeq;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      psPending.delete(seq);
      reject(new Error('守护进程 ' + verb + ' 超时（' + (timeoutMs || 8000) + 'ms 没回应）'));
    }, timeoutMs || 8000);
    psPending.set(seq, { resolve, reject, timer });
    const cmdLine = verb + '|' + seq + (extra ? '|' + extra : '') + '\n';
    if (psSock && !psSock.destroyed) psSock.write(cmdLine);
    else if (psDaemon && psDaemon.stdin && !psDaemon.stdin.destroyed) psDaemon.stdin.write(cmdLine);
    else { psPending.delete(seq); clearTimeout(timer); reject(new Error('打印守护进程未连接')); }
  });
}

// 就绪判定直接看 socket 连接（不依赖 READY 标志位，更稳）
async function ensureDaemonReady(timeoutMs) {
  const t0 = Date.now();
  const limit = timeoutMs || 10000;
  while (Date.now() - t0 < limit) {
    if (psReady || (psSock && !psSock.destroyed)) return;
    await new Promise(r => setTimeout(r, 50));
  }
  throw new Error('打印守护进程启动超时（10 秒内没连上）');
}

// 通过守护进程把字节文件发给打印机：快、稳、无重复启动开销
// 解析打印回包正文： "OK bytes=591" / "ERR xxx"
function parsePrintReply(body) {
  // OK 回包可能带附加字段（位图模式：render=.. font=..），只按前缀识别
  const m = /^OK bytes=(\d+)(?:\s|$)/.exec(body || '');
  if (m) {
    const fm = /font=([^\s]+)/.exec(body || '');
    return { ok: true, detail: '已发送 ' + m[1] + ' 字节到打印机' + (fm ? '（' + fm[1] + '）' : '') };
  }
  const e = /^ERR\s*(.*)$/.exec(body || '');
  return { ok: false, detail: e && e[1] ? e[1] : (body || '守护进程无返回') };
}

async function printRawBytes(cmds, printerName) {
  const t0 = Date.now();
  // cmds 现在是 Buffer 数组，直接 concat 写文件（避免 base64 编码开销）
  // 用 C:\Windows\Temp（纯 ASCII），避免 PowerShell daemon 按 GBK 解析时中文路径乱码
  const tmpDir = 'C:/Windows/Temp';
  const binFile = path.join(tmpDir, 'pos_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6) + '.bin');
  const buf = Buffer.concat(cmds);
  fs.writeFileSync(binFile, buf);
  const t2 = Date.now();   // 写临时文件耗时
  try {
    const r = await daemonRequest('PRINT', 8000, printerName + '|' + binFile);
    const pr = parsePrintReply(r.body);
    pr.ms = r.ms;
    // 黑窗口打印计时，方便现场定位慢在哪：daemon 内部耗时 vs 整体往返
    console.log('[print] ' + printerName + ' -> ' + (pr.ok ? 'OK' : 'FAIL') +
      ' | daemon内部=' + (r.ms !== null && r.ms !== undefined ? r.ms + 'ms' : '?') +
      ' | 写文件=' + (t2 - t0) + 'ms 往返=' + (Date.now() - t2) + 'ms' +
      ' | 整体=' + (Date.now() - t0) + 'ms' + (pr.ok ? '' : ' | ' + pr.detail));
    return pr;
  } catch (e) {
    console.log('[print] ' + printerName + ' -> FAIL | 整体往返=' + (Date.now() - t0) + 'ms | ' + e.message);
    return { ok: false, detail: e.message };
  } finally {
    try { fs.unlinkSync(binFile); } catch (e) {}
  }
}

// 位图模式：把票据描述交给守护进程，用 Windows「宋体」渲染成位图后打印
//   中文 = 真正的宋体、小四号（12pt）；排版由 GDI 真实测量，不会错位/变形
async function printRenderedTicket(spec, printerName) {
  const t0 = Date.now();
  const jsonFile = path.join('C:/Windows/Temp', 'pos_spec_' + Date.now() + '_' +
    Math.random().toString(36).slice(2, 6) + '.json');
  fs.writeFileSync(jsonFile, JSON.stringify(spec), 'utf8');
  const t1 = Date.now();
  try {
    const r = await daemonRequest('RENDER', 15000, printerName + '|' + jsonFile);
    const pr = parsePrintReply(r.body);
    pr.ms = r.ms;
    console.log('[print-bitmap] ' + printerName + ' -> ' + (pr.ok ? 'OK' : 'FAIL') +
      ' | daemon内部=' + (r.ms !== null && r.ms !== undefined ? r.ms + 'ms' : '?') +
      ' | 写JSON=' + (t1 - t0) + 'ms 往返=' + (Date.now() - t1) + 'ms' +
      ' | 整体=' + (Date.now() - t0) + 'ms | ' + (r.body || ''));
    return pr;
  } catch (e) {
    console.log('[print-bitmap] ' + printerName + ' -> FAIL | 整体=' + (Date.now() - t0) + 'ms | ' + e.message);
    return { ok: false, detail: e.message };
  } finally {
    try { fs.unlinkSync(jsonFile); } catch (e) {}
  }
}

// 兜底：普通打印机（A4 / 没装热敏机时），生成网页交给 Edge/Chrome 静默打印
function printHtml(html, printerName) {
  return new Promise(res => {
    const f = path.join(os.tmpdir(), 'pos_ticket_' + Date.now() + '.html');
    fs.writeFileSync(f, html, 'utf8');
    const candidates = [
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
    ];
    const exe = candidates.find(p => fs.existsSync(p));
    if (!exe) return res({ ok: false, detail: 'no browser for html print' });
    const p = spawn(exe, ['--headless=new', '--disable-gpu', '--no-pdf-header-footer',
      '--print-to-printer=' + printerName, '--print-to-no-pdf-header-footer', f], { windowsHide: true });
    const t = setTimeout(() => p.kill(), 20000);
    p.on('close', code => { clearTimeout(t); res({ ok: code === 0, detail: 'html print exit ' + code }); });
  });
}

function receiptHtml(order, cfg) {
  const rows = order.items.map(it =>
    '<tr><td class="q">' + it.qty + 'x</td><td>' + it.name + '</td><td class="p">₡' +
    (it.qty * it.price).toLocaleString('en-US') + '</td></tr>').join('');
  return '<!doctype html><meta charset="utf-8"><style>' +
    '@page{size:80mm auto;margin:2mm}body{font:13px/1.5 "Segoe UI","Microsoft YaHei",sans-serif;width:76mm}' +
    'h1{font-size:18px;text-align:center;margin:0 0 4px}.c{text-align:center}' +
    'table{width:100%;border-collapse:collapse;margin:8px 0}td{vertical-align:top;padding:2px 0}' +
    'td.q{width:24px;font-weight:700}td.p{text-align:right;white-space:nowrap}' +
    'hr{border:0;border-top:1px dashed #000}.tot{font-size:17px;font-weight:700;text-align:right}' +
    '</style><h1>COMIDA CHINA</h1>' +
    '<div class="c">' + (order.table ? 'MESA ' + order.table : 'MOSTRADOR') + ' · Orden #' + order.id + '</div>' +
    '<div class="c">' + new Date().toLocaleString('es-CR') + '</div><hr>' +
    '<table>' + rows + '</table><hr>' +
    ((Number(order.serviceFee) || 0) > 0
      ? '<div style="text-align:right">Servicio / 服务费 ₡' + Number(order.serviceFee).toLocaleString('en-US') + '</div>' : '') +
    '<div class="tot">TOTAL ₡' + order.total.toLocaleString('en-US') + '</div>' +
    (order.note ? '<p>Nota: ' + order.note + '</p>' : '') +
    '<div class="c">Gracias por su visita / 谢谢惠顾</div>';
}

async function printOrder(order, cfgOverride) {
  const cfg = Object.assign(readCfg(), cfgOverride || {});
  const mode = cfg.mode || 'raw';
  let printers = [];
  const want = (cfg.printer || '').trim();
  // 关键：设置里已经选了打印机 → 直接打，绝不为「打印」去枚举设备。
  //   枚举一次 Get-Printer 实测 5~11 秒，这是下单慢的头号元凶。
  let rp = want ? { name: want, warn: '' } : null;
  if (!rp) {
    try { printers = await listPrintersCached(false); } catch (e) {}
    rp = await resolvePrinter(cfg, printers);
  }
  const results = [];
  const copies = (cfg.copies && cfg.copies.length) ? cfg.copies : ['COCINA'];

  if (!rp.name) {
    // 一台打印机都没有 → 直接给清晰提示，不白忙活
    for (const copyName of copies) results.push({ copy: copyName, ok: false, detail: rp.warn });
    return { ok: false, used: '', printerNames: printers.map(p => p.name), results };
  }

  for (const copyName of copies) {
    const ord = Object.assign({}, order, { copy: copies.length > 1 ? copyName : '' });
    if (mode === 'raw') {
      // 默认走位图（中文 = 宋体小四）；设置里选「点阵快速」才走老的 ESC/POS 文本模式
      const useBitmap = (cfg.render || 'bitmap') !== 'text';
      const cmds = useBitmap ? null : buildReceipt(ord, cfg);
      const spec = useBitmap ? buildTicketSpec(ord, cfg) : null;
      const printOnce = async pname => {
        if (!useBitmap) return printRawBytes(cmds, pname);
        const rb = await printRenderedTicket(spec, pname);
        if (rb.ok) return Object.assign({}, rb, { mode: 'bitmap' });
        // 位图渲染不可用（缺字体 / 老守护进程 / 打印机不吃图形指令）→ 退回点阵文本，保证不丢单
        console.log('[print] 位图模式失败，回退点阵文本模式：' + rb.detail);
        const rt = await printRawBytes(buildReceipt(ord, cfg), pname);
        return Object.assign({}, rt, { mode: 'text-fallback', firstErr: rb.detail });
      };
      let r = await printOnce(rp.name);
      if (!r.ok) {
        // 打印机可能在设置之后被改名/卸载：重新找一台再试一次（只在失败时才付这个代价）
        const alt = await reResolvePrinter(rp.name);
        if (alt && alt !== rp.name) {
          console.log('[print] 首次失败，改用「' + alt + '」重试');
          const r2 = await printOnce(alt);
          rp = { name: alt, warn: rp.warn };
          r = Object.assign({}, r2, { firstErr: r.detail });
        }
      }
      if (!r.ok && cfg.fallbackPrinter && cfg.fallbackPrinter !== rp.name) {
        const r2 = await printHtml(receiptHtml(ord, cfg), cfg.fallbackPrinter);
        results.push({ copy: copyName, printer: rp.name, ...r2, mode: 'html-fallback', firstErr: r.detail });
      } else {
        results.push({ copy: copyName, printer: rp.name, ...r, mode: r.mode || 'raw' });
      }
    } else {
      const r = await printHtml(receiptHtml(ord, cfg), rp.name);
      results.push({ copy: copyName, mode: 'html', printer: rp.name, ...r });
    }
  }
  const ok = results.every(x => x.ok);
  return { ok, used: rp.name, warn: rp.warn || '', printerNames: printers.map(p => p.name), results };
}

// ---------- 日结单（每日总结单） ----------
// 汇总某一天的订单：orders/YYYYMMDD.jsonl（文件名按本机本地日期，与下单时的 day 一致）
function summarizeDay(day) {
  day = String(day || '').replace(/-/g, '');
  const file = path.join(ORDERS_DIR, day + '.jsonl');
  let orders = [];
  if (fs.existsSync(file)) {
    orders = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch (e) { return null; } }).filter(Boolean);
  }
  const sum = {
    day, orders: orders.length, total: 0,
    types: { AQUI: { n: 0, amt: 0 }, LLEVAR: { n: 0, amt: 0 }, MESA: { n: 0, amt: 0 } },
    pays: { EFECTIVO: { n: 0, amt: 0 }, TARJETA: { n: 0, amt: 0 }, SINPE: { n: 0, amt: 0 } },
    payUnknown: { n: 0, amt: 0 },   // 旧订单没记支付方式（升级前的单），单独统计
    svc: { n: 0, amt: 0 },          // 堂食服务费（旧订单无 serviceFee 字段，不计）
    items: []
  };
  const map = new Map();
  orders.forEach(o => {
    const amt = Number(o.total) || 0;
    sum.total += amt;
    const sf = Number(o.serviceFee) || 0;
    if (sf > 0) { sum.svc.n++; sum.svc.amt += sf; }
    // 旧订单没有 pay 字段 → 计入「未记录」，避免支付方式整段空白像坏了
    const pay = o.pay || '';
    if (sum.pays[pay]) { sum.pays[pay].n++; sum.pays[pay].amt += amt; }
    else { sum.payUnknown.n++; sum.payUnknown.amt += amt; }
    const t = o.table ? 'MESA' : (o.type === 'LLEVAR' ? 'LLEVAR' : 'AQUI');
    sum.types[t].n++; sum.types[t].amt += amt;
    (o.items || []).forEach(it => {
      const k = String(it.name);
      const e = map.get(k) || { name: k, qty: 0, amt: 0 };
      const q = Number(it.qty) || 0;
      e.qty += q;
      e.amt += q * (Number(it.price) || 0);
      map.set(k, e);
    });
  });
  sum.items = Array.from(map.values()).sort((a, b) => (b.qty - a.qty) || (b.amt - a.amt));
  return sum;
}

// 本地日期字符串（YYYYMMDD），shift = 相对今天的天数偏移
function localDay(shift) {
  const d = new Date();
  d.setDate(d.getDate() + (shift || 0));
  return d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
}

// 打印日结单：只走位图渲染（宋体），失败可随时在页面重打
async function printSummary(day, cfgOverride) {
  const cfg = Object.assign(readCfg(), cfgOverride || {});
  const sum = summarizeDay(day);
  if (!sum.orders) return { ok: false, day, sum, detail: '这天没有订单，不用打' };
  const spec = buildSummarySpec(sum, cfg);
  const want = (cfg.printer || '').trim();
  let rp = want ? { name: want, warn: '' } : null;
  if (!rp) {
    let printers = [];
    try { printers = await listPrintersCached(false); } catch (e) {}
    rp = await resolvePrinter(cfg, printers);
  }
  if (!rp.name) return { ok: false, day, sum, detail: rp.warn };
  let r = await printRenderedTicket(spec, rp.name);
  if (!r.ok) {
    const alt = await reResolvePrinter(rp.name);
    if (alt && alt !== rp.name) r = await printRenderedTicket(spec, alt);
  }
  return { ok: r.ok, day, sum, printer: rp.name, detail: r.detail || '' };
}

// 每天凌晨自动打印前一天的日结单（默认 3 点，config.autoSummaryHour 可改）
//   状态记在 orders/_autosummary.json；失败每 10 分钟重试，成功才记 lastSent
const AUTO_FILE = path.join(ORDERS_DIR, '_autosummary.json');
let autoState = { lastSent: '', lastAttempt: 0 };
try { if (fs.existsSync(AUTO_FILE)) autoState = Object.assign(autoState, JSON.parse(fs.readFileSync(AUTO_FILE, 'utf8'))); } catch (e) {}
function saveAutoState() {
  try { fs.mkdirSync(ORDERS_DIR, { recursive: true }); fs.writeFileSync(AUTO_FILE, JSON.stringify(autoState), 'utf8'); } catch (e) {}
}
async function checkAutoSummary() {
  try {
    const cfg = readCfg();
    if (cfg.autoSummary === false) return;                 // 设置里可关
    const hour = new Date().getHours();
    const trigger = Number(cfg.autoSummaryHour) || 3;
    if (hour < trigger) return;
    const day = localDay(-1);
    if (autoState.lastSent === day) return;
    if (Date.now() - (autoState.lastAttempt || 0) < 10 * 60 * 1000) return;
    autoState.lastAttempt = Date.now();
    const sum = summarizeDay(day);
    if (!sum.orders) { autoState.lastSent = day; saveAutoState(); console.log('[autosummary] ' + day + ' 无订单，跳过'); return; }
    console.log('[autosummary] 自动打印 ' + day + ' 的日结单…');
    const r = await printSummary(day);
    if (r.ok) { autoState.lastSent = day; saveAutoState(); }
    console.log('[autosummary] ' + day + ' -> ' + (r.ok ? 'OK' : (r.detail || 'FAIL')));
  } catch (e) {
    console.log('[autosummary] 异常：' + e.message);
  }
}
setTimeout(checkAutoSummary, 8000);
setInterval(checkAutoSummary, 10 * 60 * 1000);

// 客屏（第二块屏）共享数据：前台页面每点/减一个菜就 POST 一份购物车快照，
// 客屏页面（/customer）每秒轮询 GET /api/cart 实时显示菜名、数量和总价。纯内存，不落盘。
let lastCart = { seq: 0, ts: 0, table: '', type: 'AQUI', items: [], total: 0 };

// ---------- HTTP ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.css': 'text/css; charset=utf-8' };

function body(req) {
  return new Promise(res => {
    let b = '';
    req.on('data', d => { b += d; if (b.length > 2e6) req.destroy(); });
    req.on('end', () => { try { res(JSON.parse(b || '{}')); } catch (e) { res({}); } });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const send = (code, data, type) => {
    res.writeHead(code, { 'Content-Type': type || 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(typeof data === 'string' ? data : JSON.stringify(data));
  };

  try {
    if (url.pathname === '/' || url.pathname === '/pos') {
      return send(200, fs.readFileSync(path.join(ROOT, 'pos.html'), 'utf8'), MIME['.html']);
    }
    if (url.pathname === '/customer' || url.pathname === '/customer.html') {
      return send(200, fs.readFileSync(path.join(ROOT, 'customer.html'), 'utf8'), MIME['.html']);
    }
    if (url.pathname === '/api/menu') return send(200, loadMenu());
    // ---------- 菜单后台 ----------
    if (url.pathname === '/admin' || url.pathname === '/admin.html') {
      return send(200, fs.readFileSync(path.join(ROOT, 'admin.html'), 'utf8'), MIME['.html']);
    }
    if (url.pathname === '/api/menu-admin') {
      return send(200, JSON.parse(fs.readFileSync(path.join(ROOT, 'menu.json'), 'utf8')));
    }
    if (url.pathname === '/api/menu-save' && req.method === 'POST') {
      const cats = await body(req);
      if (!Array.isArray(cats) || !cats.length ||
          !cats.every(c => c && typeof c.name === 'string' && Array.isArray(c.items)))
        return send(400, { ok: false, err: '菜单数据格式不对（必须是分类数组）' });
      for (const c of cats) for (const it of c.items) {
        if (!it || typeof it.es !== 'string' || !it.es.trim() || !Array.isArray(it.prices) || !it.prices.length)
          return send(400, { ok: false, err: '菜品缺名称或价格档' });
        for (const p of it.prices)
          if (typeof p.key !== 'string' || !p.key.trim() || !(Number(p.price) >= 0))
            return send(400, { ok: false, err: '价格档不对: ' + it.es });
      }
      // 写前备份（orders/menu-backup，保留最近 5 份）
      const bakDir = path.join(ROOT, 'orders', 'menu-backup');
      fs.mkdirSync(bakDir, { recursive: true });
      const stamp = new Date().toISOString().slice(0, 19).replace(/[-:T]/g, '');
      fs.writeFileSync(path.join(bakDir, 'menu-' + stamp + '.json'),
        fs.readFileSync(path.join(ROOT, 'menu.json')), 'utf8');
      const baks = fs.readdirSync(bakDir).filter(f => /^menu-\d+\.json$/.test(f)).sort();
      while (baks.length > 5) fs.unlinkSync(path.join(bakDir, baks.shift()));
      // 写入（保持原 1 空格缩进风格）
      fs.writeFileSync(path.join(ROOT, 'menu.json'), JSON.stringify(cats, null, 1), 'utf8');
      const g = gbkRebuild(false);
      return send(200, { ok: true, gbk: g });
    }
    if (url.pathname === '/api/gbk-rebuild' && req.method === 'POST') {
      return send(200, gbkRebuild(true));
    }
    // 页面用它判断「服务是不是旧版本」：和页面里的 PAGE_V 不一致就提示重启
    if (url.pathname === '/api/version') return send(200, { v: SERVER_V });
    if (url.pathname === '/api/config') {
      if (req.method === 'POST') { const c = await body(req); writeCfg(Object.assign(readCfg(), c)); }
      return send(200, readCfg());
    }
    if (url.pathname === '/api/printers') {
      // 打开设置页 → 强制刷新（刚插上的打印机要能立刻看到）
      try {
        const list = await listPrintersCached(true);
        return send(200, list);
      } catch (e) {
        return send(200, []);
      }
    }
    if (url.pathname === '/api/print') {
      const d = await body(req);
      const r = await printOrder(d.order || d, d.cfg);
      return send(200, r);
    }
    if (url.pathname === '/api/test-print') {
      const d = await body(req);
      const r = await printOrder({
        id: 'TEST', table: 'TEST', type: 'AQUI', items: [
          { name: 'PRUEBA / 测试打印', qty: 1, price: 0 },
          { name: 'A1. Bistec encebollado / 煎牛排', qty: 2, price: 4500 }
        ], note: 'Prueba de impresión / 打印测试', total: 9000
      }, d.cfg);
      return send(200, r);
    }
    if (url.pathname === '/api/drawer' && req.method === 'POST') {
      // 开钱箱：钱箱接在热敏打印机 RJ11 口上，直接发 ESC/POS 开箱脉冲（ESC p 0 25 250）
      // 不写任何数据文件，用配置里已有的打印机
      try {
        const cfg = readCfg();
        const printers = await listPrintersCached(false);
        const rp = await resolvePrinter(cfg, printers);
        if (!rp.name) return send(200, { ok: false, detail: rp.warn || '没有可用打印机' });
        const r = await printRawBytes([Buffer.from([0x1B, 0x70, 0x00, 0x19, 0xFA])], rp.name);
        return send(200, r);
      } catch (e) {
        return send(200, { ok: false, detail: e.message });
      }
    }
    if (url.pathname === '/api/order') {
      const d = await body(req);
      const { id, day, file } = nextId();
      const order = {
        id, ts: new Date().toISOString(),
        table: d.table || '', type: d.type || 'AQUI',
        pay: ['EFECTIVO', 'TARJETA', 'SINPE'].indexOf(d.pay) >= 0 ? d.pay : 'EFECTIVO',
        items: d.items || [], note: d.note || '', total: d.total || 0,
        serviceFee: Number(d.serviceFee) || 0   // 堂食服务费（老订单无此字段，日结单按 0 处理）
      };
      let print = { ok: true, results: [], skipped: !d.doPrint };
      if (d.doPrint) {
        // 异步打印：不等打印完成就返回，前端点了立刻有反应，不卡界面
        print = { ok: true, pending: true, results: [] };
        lastPrint = { ts: Date.now(), id, done: false, ok: true };
        printOrder(order, d.cfg).then(r => {
          lastPrint = {
            ts: Date.now(), id, done: true, ok: r.ok, used: r.used, warn: r.warn || '',
            detail: (r.results || []).map(x => x.detail).filter(Boolean).join('; ')
          };
          console.log('[order] #' + id + ' 打印' + (r.ok ? '成功' : '失败：' + lastPrint.detail));
        }).catch(e => {
          lastPrint = { ts: Date.now(), id, done: true, ok: false, detail: e.message };
          console.log('[order] #' + id + ' 打印异常：' + e.message);
        });
      }
      order.printed = !d.doPrint ? false : true;
      fs.appendFileSync(file, JSON.stringify(order) + '\n', 'utf8');
      return send(200, { ok: true, order, print });
    }
    // 前端用来查最近一次打印结果（异步打印后回查）
    if (url.pathname === '/api/last-print') return send(200, lastPrint || { done: true, ok: true });
    // 客屏同步：前台 POST 快照，客屏 GET 轮询
    if (url.pathname === '/api/cart') {
      if (req.method === 'POST') {
        const d = await body(req);
        const items = Array.isArray(d.items) ? d.items
          .filter(it => it && it.name && Number(it.qty) > 0).slice(0, 200)
          .map(it => ({ name: String(it.name).slice(0, 200), qty: Math.min(999, Number(it.qty) || 0), price: Math.max(0, Number(it.price) || 0) }))
          : [];
        lastCart = {
          seq: Number(d.seq) || (lastCart.seq + 1), ts: Date.now(),
          table: String(d.table || '').slice(0, 10),
          type: d.type === 'LLEVAR' ? 'LLEVAR' : 'AQUI',
          items,
          // total 优先用前端推的（含堂食服务费）；旧版前端没推就按菜品算
          total: (Number(d.total) >= 0 && d.total !== undefined && d.total !== null && d.total !== '')
            ? Number(d.total) : items.reduce((s, it) => s + it.qty * it.price, 0)
        };
      }
      return send(200, lastCart);
    }
    if (url.pathname === '/api/orders') {
      const day = url.searchParams.get('day') ||
        (new Date().toISOString().slice(0, 10).replace(/-/g, ''));
      const file = path.join(ORDERS_DIR, day + '.jsonl');
      const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split('\n').filter(Boolean) : [];
      return send(200, lines.map(l => JSON.parse(l)));
    }
    if (url.pathname === '/api/summary') {
      const day = url.searchParams.get('day') || localDay(0);
      return send(200, summarizeDay(day));
    }
    // 最近 14 天每天的单数/总额（日结单弹窗的快捷日期用）
    if (url.pathname === '/api/summary-days') {
      const days = [];
      for (let i = 0; i < 14; i++) days.push(localDay(-i));
      const list = days.map(day => {
        const file = path.join(ORDERS_DIR, day + '.jsonl');
        let n = 0, total = 0;
        if (fs.existsSync(file)) {
          fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).forEach(l => {
            try { const o = JSON.parse(l); n++; total += Number(o.total) || 0; } catch (e) {}
          });
        }
        return { day, orders: n, total };
      });
      return send(200, list);
    }
    if (url.pathname === '/api/summary-print') {
      const d = await body(req);
      const day = String(d.day || localDay(0)).replace(/-/g, '');
      if (!/^\d{8}$/.test(day)) return send(400, { error: '日期格式应为 YYYYMMDD' });
      const r = await printSummary(day, d.cfg);
      return send(200, r);
    }
    send(404, { error: 'not found' });
  } catch (e) {
    console.error('[API 500]', req.method, url.pathname, '-', e.stack || e.message);
    send(500, { error: e.message });
  }
});

server.on('error', e => {
  if (e.code === 'EADDRINUSE') {
    console.log('服务已经在运行（端口 ' + PORT + ' 被占用），直接打开页面。');
    if (OPEN_BROWSER) {
      openBrowser();
      setTimeout(openCustomerScreen, 1000);
      setTimeout(() => process.exit(0), 6000);   // 等客屏拉起再退，不截断定时器
      return;
    }
    process.exit(0);   // 已有一个在跑 → 本实例正常退出，不报错
  }
  console.error('启动失败:', e.message);
  process.exit(1);
});
server.listen(PORT, '127.0.0.1', () => {
  console.log('前台点单服务已启动: http://127.0.0.1:' + PORT + '/');
  console.log('（关闭本窗口即停止服务；订单存于 orders 文件夹）');
  // 启动 PowerShell 打印守护进程（常驻，首次打印无需等待 PowerShell 启动）
  startDaemon();
  // 预热：把打印机列表先缓存好、并测一次往返，这样第一单也不用等
  setTimeout(async () => {
    try {
      const t2 = Date.now();
      await daemonRequest('PING', 5000);
      console.log('[预热] 守护进程就绪，往返 ' + (Date.now() - t2) + 'ms');
      const t = Date.now();
      const list = await listPrintersCached(true);
      console.log('[预热] 打印机 ' + list.length + ' 台，耗时 ' + (Date.now() - t) + 'ms');
    } catch (e) {
      console.log('[预热] 未完成（不影响使用）：' + e.message);
    }
  }, 500);
  if (OPEN_BROWSER) { setTimeout(openBrowser, 400); setTimeout(openCustomerScreen, 1500); }
});
